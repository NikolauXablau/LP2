﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PReava0030482513005
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstPosiMat.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[] A = new double[10] { 1.50, 2.50, 3.50, 4.50, 5.50, 6.50, 7.50, 8.50, 9.50, 10.50 };
            double[] B = new double[10];
            String[] Escrita = new String[10];

            for (int i = 0; i < 10; i++)
            {
                if (i % 2 == 0)
                    B[i] = (A[i] * 4);
                else B[i] = (A[i] + 4);

                Escrita[i] = $"Posição: {i} Matriz A = {A[i].ToString("N2")} Matriz B = {B[i].ToString("N2")} \n";
                lstPosiMat.Items.Add(Escrita[i]);
            }


        }   
    }
}
