﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace PContato0030482513005
{
    internal class Cidade //Variáveis internas.
    {
        private int idcidade;
        private string nomecidade;
        private string ufcidade;

        public int Idcidade //Variáveis publicas,interagem com os dados das variáveis internas.
        {
            get 
            {
                return idcidade; //Pega valor da variável interna
            }
            set 
            {
                idcidade = value; //Altera valor da variável interna
            }

        }
        public string Nomecidade
        {
            get
            {
                return nomecidade;
            }
            set
            {
                nomecidade = value;
            }

        }
        public string Ufcidade
        {
            get
            {
                return ufcidade;
            }
            set
            {
                ufcidade = value;
            }

        }
        public DataTable Listar()//Criando método tipo DataTable
        {
            SqlDataAdapter daCidade;
            DataTable dtCidade = new DataTable();

            try
            {
                daCidade = new SqlDataAdapter("SELECT * FROM CIDADE ORDER BY NOME_CIDADE",
                    frmPrincipal.conexao);
                daCidade.Fill(dtCidade);
                daCidade.FillSchema(dtCidade, SchemaType.Source);
            }
            catch (Exception) 
            {
                throw;
            }
            return dtCidade;
        }


    }
}
