﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercicio5 : Form
    {

        public Exercicio5()
        {
            InitializeComponent();
        }
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int N = 6*10, Cancela=0;
            String[,] AlunosResp = new String[N, 10];
            String[] Respostas = new String[10] { "C", "B", "E", "C", "D", "B", "D", "B", "B", "D"};
            String[] Perguntas = new String[10] { "Qual palavra-chave é usada para declarar uma variável de número inteiro em C#?\n (A: string, B: double, C: int, D: bool, E: char)",
                "Qual palavra-chave é usada para definir uma classe em C#?\n(A: method, B: class, C: object, D: struct, E: interface)",
                "Qual das seguintes opções NÃO é um tipo de loop em C#?\n(A: for, B: while, C: do-while, D: foreach, E: repeat)",
                "Qual palavra-chave é usada para criar uma nova instância (objeto) de uma classe?\n(A: create, B: instance, C: new, D: alloc, E: object)",
                "Qual bloco é usado para capturar exceções (erros) em C#?\n(A: try, B: error, C: if-error, D: catch, E: finally)",
                "Qual palavra-chave indica que um método não retorna nenhum valor?\n(A: null, B: void, C: int, D: return, E: empty)",
                "Qual diretiva é usada no início de um arquivo C# para incluir um namespace?\n (A: import, B: include, C: namespace, D: using, E: require)",
                "Qual modificador de acesso torna um membro acessível apenas dentro da própria classe?\n(A: public, B: private, C: protected, D: internal, E: static)",
                "Qual operador é usado para verificar se dois valores são iguais em C#?\n(A: =, B: ==, C: ===, D: is, E: .Equals())",
                "Qual operador é comumente usado para concatenar (juntar) strings em C#?\n(A: &, B: &&, C: ., D: +, E: add)"};
            String Auxiliar = "";
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                        Auxiliar = Interaction.InputBox($"\n{Perguntas[j]}", $"Prova do Aluno: {i+1}. Pergunta {j+1}");
                        Auxiliar = Auxiliar.ToUpper();
                        if (Auxiliar == "")
                        {
                            if (MessageBox.Show("Deseja cancelar a operação?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                Cancela = 1;
                                break;
                            }
                            else
                            {
                                MessageBox.Show("Você deve responder antes de enviar a resposta");
                                j--;
                                continue;
                            }
                        }
                        else if (Auxiliar != "A" && Auxiliar != "B" && Auxiliar != "C" && Auxiliar != "D" && Auxiliar != "E")
                        {
                            MessageBox.Show("A resposta só pode ser A, B, C, D ou E, digite uma resposta válida");
                            j--;
                            continue;
                        }
                        else
                        {
                            AlunosResp[i, j] = Auxiliar;
                        }
                        if(AlunosResp[i, j] == Respostas[j])
                        {
                            lstResp.Items.Add($"O Aluno {i+1} acertou a questão {j+1}; Era {Respostas[j]}, Respondeu {AlunosResp[i,j]}");
                        } else 
                        {
                            lstResp.Items.Add($"O Aluno {i + 1} errou a questão {j + 1}; Era {Respostas[j]}, Respondeu {AlunosResp[i, j]}");
                        }
                }
                if (Cancela == 1)
                    break;
            }
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstResp.Items.Clear();
        }
    }
}
