﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[20, 3];
            String Auxiliar = "", Saida = "";
            double Media = 0;
            int Cancela = 0;
            for (int i = 0; i < 20; i++)
            {
                
                for (int j = 0; j < 3; j++)
                {
                    Auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do Aluno {i + 1}",
                        "Entrada de dados");

                    if (Auxiliar == "")
                    {
                        if (MessageBox.Show("Deseja cancelar a operação?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            Cancela = 1;
                            break;
                        }
                    }
                    else if (!double.TryParse(Auxiliar, out Notas[i, j]) || Notas[i, j] < 0 ||
                        Notas[i, j] > 10)
                    {
                        MessageBox.Show("Dado Inválido");
                        j--;
                    }
                    else
                    {
                        Media += Notas[i, j];
                    }
                    
                    if (Cancela == 1)
                        break;
                }
                if (Cancela == 1)
                    break;
                
                Saida += $"\nAluno {i + 1}: Media {Media / 3}";
                Media = 0;
                MessageBox.Show(Saida);
            }
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercicio4>().Count() > 0)
            {
                MessageBox.Show("O form já existe");
                Application.OpenForms["Exercicio4"].BringToFront();
            }
            else
            {
                Exercicio4 ObjEx4 = new Exercicio4();
                ObjEx4.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercicio5>().Count() > 0)
            {
                MessageBox.Show("O form já existe");
                Application.OpenForms["Exercicio5"].BringToFront();
            }
            else
            {
                Exercicio5 ObjEx5 = new Exercicio5();
                ObjEx5.Show();
            }
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] Numeros = new int[20];
            String Auxiliar;
            String Reverso = "";
            
            for( int i = 0; i < Numeros.Length; i++)
            {
                
                Auxiliar = Interaction.InputBox($"Adicione o número {i + 1}", "Reversor de ordem de números");
                if (Auxiliar == "")
                {
                    if (MessageBox.Show("Deseja cancelar a operação?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        break;
                    }
                }
                else if (!int.TryParse(Auxiliar, out Numeros[i]))
                {
                    MessageBox.Show("O número deve ser inteiro, insira um valor válido");
                    i--;

                }
                else if (Numeros[i] == 0)
                {
                    MessageBox.Show("Você deve digitar um valor para continuar");
                    i--;
                }
                else
                {
                    Reverso = $"{Numeros[i].ToString()}.{Reverso}";
                }
                

                    MessageBox.Show(Reverso);
            }
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList Nomes = new ArrayList() {"Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais"};
            Nomes.Remove("Otávio");
            string Auxiliar = ""; ;
            foreach (String Elemento in Nomes)
            {
                Auxiliar += Elemento+".";
            }
            MessageBox.Show(Auxiliar);
        }
    }
}
