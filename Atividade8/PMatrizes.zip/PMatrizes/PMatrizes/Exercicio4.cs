﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercicio4 : Form
    {
        public Exercicio4()
        {
            InitializeComponent();
        }

        private void BtnExecute_Click(object sender, EventArgs e)
        {
            String[] Nomes = new String[10];
            String Auxiliar = "";
            int[] Tamanho = new int[10];
            for (int i = 0; i < 10; i++)
            {
                 Auxiliar = Interaction.InputBox($"Escreva o nome do aluno {i + 1}:", "Entrada de Dados");
                if (Auxiliar == "")
                {
                    if (MessageBox.Show("Deseja cancelar a operação?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Você deve responder antes de enviar a resposta");
                        i--;
                        continue;
                    }
                }else
                    Nomes[i] = Auxiliar;
                    Tamanho[i] = (Nomes[i].Replace(" ", "")).Length;
                Nomes[i] = $"Nome: {Nomes[i]}, Número de caracteres: {Tamanho[i]} \n";
                lstNomes.Items.Add(Nomes[i]);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstNomes.Items.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();   
        }
    }
}
