﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double Altura, Peso, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void msktxtPeso_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(msktxtPeso.Text, out Peso)) || (Peso <= 0))
            {
                errorProvider1.SetError(msktxtPeso,"Valor Inválido");
                msktxtPeso.Focus();
            }
            else
            {
                errorProvider1.SetError(msktxtPeso, "");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            msktxtAltura.Text = string.Empty;
            msktxtPeso.Text = string.Empty;
            txtIMC.Text = string.Empty;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = Peso / (Math.Pow(Altura, 2));
            IMC = Math.Round(IMC, 1);

            if (IMC >= 40)
            {
                txtIMC.Text = "Obesidade Mórbida [" + IMC.ToString() + "]";
            }
            else if (IMC >= 30)
            {
                txtIMC.Text = "Obesidade [" + IMC.ToString() + "]";
            }
            else if (IMC >= 25)
            {
                txtIMC.Text = "Sobrepeso [" + IMC.ToString() + "]";
            }
            else if (IMC >= 18.5)
            {
                txtIMC.Text = "Normal [" + IMC.ToString() + "]";
            }
            else
            {
                txtIMC.Text = "Subpeso [" + IMC.ToString() + "]";
            }
 
        }

                private void msktxtAltura_Validated(object sender, EventArgs e)
                {
                    if ((!double.TryParse(msktxtAltura.Text, out Altura)) || (Altura <= 0))
                    {
                        errorProvider1.SetError(msktxtAltura, "Valor Inválido");
                        msktxtAltura.Focus();
                    }
                    else
                    {
                        errorProvider1.SetError(msktxtAltura, "");
                    }
                }
    }
}
