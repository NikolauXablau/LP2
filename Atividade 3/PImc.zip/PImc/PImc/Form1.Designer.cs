﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblAltura = new System.Windows.Forms.Label();
            this.lblPeso = new System.Windows.Forms.Label();
            this.lblIMC = new System.Windows.Forms.Label();
            this.msktxtPeso = new System.Windows.Forms.MaskedTextBox();
            this.msktxtAltura = new System.Windows.Forms.MaskedTextBox();
            this.txtIMC = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblTitulo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Font = new System.Drawing.Font("GeoSlab703 Md BT", 16F, System.Drawing.FontStyle.Bold);
            this.lblAltura.Location = new System.Drawing.Point(33, 164);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(109, 32);
            this.lblAltura.TabIndex = 0;
            this.lblAltura.Text = "Altura: ";
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Font = new System.Drawing.Font("GeoSlab703 Md BT", 16F, System.Drawing.FontStyle.Bold);
            this.lblPeso.Location = new System.Drawing.Point(33, 234);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(90, 32);
            this.lblPeso.TabIndex = 1;
            this.lblPeso.Text = "Peso: ";
            // 
            // lblIMC
            // 
            this.lblIMC.AutoSize = true;
            this.lblIMC.Font = new System.Drawing.Font("GeoSlab703 Md BT", 16F, System.Drawing.FontStyle.Bold);
            this.lblIMC.Location = new System.Drawing.Point(275, 164);
            this.lblIMC.Name = "lblIMC";
            this.lblIMC.Size = new System.Drawing.Size(198, 32);
            this.lblIMC.TabIndex = 2;
            this.lblIMC.Text = "Classificação:";
            // 
            // msktxtPeso
            // 
            this.msktxtPeso.Font = new System.Drawing.Font("GeoSlab703 Md BT", 16F, System.Drawing.FontStyle.Bold);
            this.msktxtPeso.Location = new System.Drawing.Point(142, 234);
            this.msktxtPeso.Mask = "900.00";
            this.msktxtPeso.Name = "msktxtPeso";
            this.msktxtPeso.Size = new System.Drawing.Size(100, 39);
            this.msktxtPeso.TabIndex = 4;
            this.msktxtPeso.Validated += new System.EventHandler(this.msktxtPeso_Validated);
            // 
            // msktxtAltura
            // 
            this.msktxtAltura.Font = new System.Drawing.Font("GeoSlab703 Md BT", 16F, System.Drawing.FontStyle.Bold);
            this.msktxtAltura.Location = new System.Drawing.Point(142, 161);
            this.msktxtAltura.Mask = "0.00";
            this.msktxtAltura.Name = "msktxtAltura";
            this.msktxtAltura.Size = new System.Drawing.Size(100, 39);
            this.msktxtAltura.TabIndex = 3;
            this.msktxtAltura.Validated += new System.EventHandler(this.msktxtAltura_Validated);
            // 
            // txtIMC
            // 
            this.txtIMC.Font = new System.Drawing.Font("GeoSlab703 Md BT", 16F, System.Drawing.FontStyle.Bold);
            this.txtIMC.Location = new System.Drawing.Point(479, 164);
            this.txtIMC.Multiline = true;
            this.txtIMC.Name = "txtIMC";
            this.txtIMC.Size = new System.Drawing.Size(282, 83);
            this.txtIMC.TabIndex = 5;
            // 
            // btnLimpar
            // 
            this.btnLimpar.AutoSize = true;
            this.btnLimpar.Font = new System.Drawing.Font("GeoSlab703 Md BT", 16F, System.Drawing.FontStyle.Bold);
            this.btnLimpar.Location = new System.Drawing.Point(322, 334);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(116, 42);
            this.btnLimpar.TabIndex = 6;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.AutoSize = true;
            this.btnCalcular.Font = new System.Drawing.Font("GeoSlab703 Md BT", 16F, System.Drawing.FontStyle.Bold);
            this.btnCalcular.Location = new System.Drawing.Point(75, 334);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(135, 42);
            this.btnCalcular.TabIndex = 7;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnSair
            // 
            this.btnSair.AutoSize = true;
            this.btnSair.Font = new System.Drawing.Font("GeoSlab703 Md BT", 16F, System.Drawing.FontStyle.Bold);
            this.btnSair.Location = new System.Drawing.Point(552, 334);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(77, 42);
            this.btnSair.TabIndex = 8;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("GeoSlab703 Md BT", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(28, 41);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(720, 72);
            this.lblTitulo.TabIndex = 9;
            this.lblTitulo.Text = "CALCULADORA DE IMC";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtIMC);
            this.Controls.Add(this.msktxtAltura);
            this.Controls.Add(this.msktxtPeso);
            this.Controls.Add(this.lblIMC);
            this.Controls.Add(this.lblPeso);
            this.Controls.Add(this.lblAltura);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.Label lblIMC;
        private System.Windows.Forms.MaskedTextBox msktxtPeso;
        private System.Windows.Forms.MaskedTextBox msktxtAltura;
        private System.Windows.Forms.TextBox txtIMC;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Label lblTitulo;
    }
}

