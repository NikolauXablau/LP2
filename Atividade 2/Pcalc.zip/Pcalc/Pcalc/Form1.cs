﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;
        public Form1()
            
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNum2_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNum2, "");
                Numero2 = Convert.ToDouble(txtNum2.Text);
            }
            catch
            {
                errorProvider2.SetError(txtNum2, "numero inválido");
                txtNum2.Focus();
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            Resultado = (Numero1 + Numero2);
            txtResultado.Text = Resultado.ToString();
        }

        private void btnSubtrai_Click(object sender, EventArgs e)
        {

                Resultado = (Numero1 - Numero2);
                txtResultado.Text = Resultado.ToString();
        }

        private void btnMultiplica_Click(object sender, EventArgs e)
        {
            Resultado = (Numero1 * Numero2);
            txtResultado.Text = Resultado.ToString();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            if (Numero2 == 0)
            {
                errorProvider2.SetError(txtNum2, "numero 2 não é possíuvel dividir por 0");
                txtNum2.Focus();
            }
            else
            {
                Resultado = (Numero1 / Numero2);
                txtResultado.Text = Resultado.ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();
            txtNum1.Focus();
        }

        private void txtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtNum1_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out Numero1))
            {
                errorProvider1.SetError(txtNum1, "Número 1 inválido");
                txtNum1.Focus();
            } else
            {
                errorProvider1.SetError(txtNum1, "");
            }
        }
    }
}
