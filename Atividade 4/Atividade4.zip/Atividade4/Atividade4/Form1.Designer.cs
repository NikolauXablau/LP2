﻿namespace Atividade4
{
    partial class Calculadora_Tipo_Triângulo
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblLadoA = new System.Windows.Forms.Label();
            this.lblLadoC = new System.Windows.Forms.Label();
            this.lblLadoB = new System.Windows.Forms.Label();
            this.lblTipTriangle = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.txtTipTriangle = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnSair = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lblTitulo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLadoA
            // 
            this.lblLadoA.AutoSize = true;
            this.lblLadoA.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblLadoA.Font = new System.Drawing.Font("Clarendon Blk BT", 12F, System.Drawing.FontStyle.Italic);
            this.lblLadoA.Location = new System.Drawing.Point(99, 194);
            this.lblLadoA.Name = "lblLadoA";
            this.lblLadoA.Size = new System.Drawing.Size(82, 24);
            this.lblLadoA.TabIndex = 0;
            this.lblLadoA.Text = "Lado A";
            // 
            // lblLadoC
            // 
            this.lblLadoC.AutoSize = true;
            this.lblLadoC.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblLadoC.Font = new System.Drawing.Font("Clarendon Blk BT", 12F, System.Drawing.FontStyle.Italic);
            this.lblLadoC.Location = new System.Drawing.Point(99, 306);
            this.lblLadoC.Name = "lblLadoC";
            this.lblLadoC.Size = new System.Drawing.Size(83, 24);
            this.lblLadoC.TabIndex = 1;
            this.lblLadoC.Text = "Lado C";
            // 
            // lblLadoB
            // 
            this.lblLadoB.AutoSize = true;
            this.lblLadoB.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblLadoB.Font = new System.Drawing.Font("Clarendon Blk BT", 12F, System.Drawing.FontStyle.Italic);
            this.lblLadoB.Location = new System.Drawing.Point(99, 251);
            this.lblLadoB.Name = "lblLadoB";
            this.lblLadoB.Size = new System.Drawing.Size(83, 24);
            this.lblLadoB.TabIndex = 2;
            this.lblLadoB.Text = "Lado B";
            // 
            // lblTipTriangle
            // 
            this.lblTipTriangle.AutoSize = true;
            this.lblTipTriangle.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblTipTriangle.Font = new System.Drawing.Font("Clarendon Blk BT", 12F, System.Drawing.FontStyle.Italic);
            this.lblTipTriangle.Location = new System.Drawing.Point(468, 196);
            this.lblTipTriangle.Name = "lblTipTriangle";
            this.lblTipTriangle.Size = new System.Drawing.Size(177, 24);
            this.lblTipTriangle.TabIndex = 3;
            this.lblTipTriangle.Text = "Seu triângulo é:";
            // 
            // txtA
            // 
            this.txtA.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtA.Font = new System.Drawing.Font("Clarendon BT", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtA.Location = new System.Drawing.Point(201, 194);
            this.txtA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(100, 29);
            this.txtA.TabIndex = 4;
            this.txtA.Validated += new System.EventHandler(this.txtA_Validated);
            // 
            // txtB
            // 
            this.txtB.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtB.Font = new System.Drawing.Font("Clarendon BT", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtB.Location = new System.Drawing.Point(203, 251);
            this.txtB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(100, 29);
            this.txtB.TabIndex = 5;
            this.txtB.Validated += new System.EventHandler(this.txtB_Validated);
            // 
            // txtC
            // 
            this.txtC.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtC.Font = new System.Drawing.Font("Clarendon BT", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtC.Location = new System.Drawing.Point(201, 306);
            this.txtC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(100, 29);
            this.txtC.TabIndex = 6;
            this.txtC.Validated += new System.EventHandler(this.txtC_Validated);
            // 
            // txtTipTriangle
            // 
            this.txtTipTriangle.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtTipTriangle.Font = new System.Drawing.Font("Clarendon BT", 10.8F);
            this.txtTipTriangle.Location = new System.Drawing.Point(665, 192);
            this.txtTipTriangle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTipTriangle.Name = "txtTipTriangle";
            this.txtTipTriangle.Size = new System.Drawing.Size(219, 29);
            this.txtTipTriangle.TabIndex = 7;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // btnSair
            // 
            this.btnSair.AutoSize = true;
            this.btnSair.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnSair.Font = new System.Drawing.Font("Clarendon Blk BT", 12F, System.Drawing.FontStyle.Italic);
            this.btnSair.Location = new System.Drawing.Point(657, 455);
            this.btnSair.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 36);
            this.btnSair.TabIndex = 8;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.AutoSize = true;
            this.btnCalcular.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnCalcular.Font = new System.Drawing.Font("Clarendon Blk BT", 12F, System.Drawing.FontStyle.Italic);
            this.btnCalcular.Location = new System.Drawing.Point(433, 455);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(120, 36);
            this.btnCalcular.TabIndex = 9;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.AutoSize = true;
            this.btnLimpar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnLimpar.Font = new System.Drawing.Font("Clarendon Blk BT", 12F, System.Drawing.FontStyle.Italic);
            this.btnLimpar.Location = new System.Drawing.Point(204, 455);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(107, 36);
            this.btnLimpar.TabIndex = 10;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblTitulo.Font = new System.Drawing.Font("Clarendon Blk BT", 20F, System.Drawing.FontStyle.Italic);
            this.lblTitulo.Location = new System.Drawing.Point(197, 66);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(564, 41);
            this.lblTitulo.TabIndex = 11;
            this.lblTitulo.Text = "Calculadora Tipo de Triângulo";
            // 
            // Calculadora_Tipo_Triângulo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImage = global::Atividade4.Properties.Resources.maxresdefault1;
            this.ClientSize = new System.Drawing.Size(965, 538);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.txtTipTriangle);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lblTipTriangle);
            this.Controls.Add(this.lblLadoB);
            this.Controls.Add(this.lblLadoC);
            this.Controls.Add(this.lblLadoA);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Calculadora_Tipo_Triângulo";
            this.Text = "Calculadora_Tipo_Triângulo";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLadoA;
        private System.Windows.Forms.Label lblLadoC;
        private System.Windows.Forms.Label lblLadoB;
        private System.Windows.Forms.Label lblTipTriangle;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.TextBox txtTipTriangle;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label lblTitulo;
    }
}

