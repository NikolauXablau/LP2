﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class Calculadora_Tipo_Triângulo : Form
    {
        double A, B, C;

        private void txtA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtA.Text, out double result))
            {
                errorProvider1.SetError(txtA, "Por favor, insira um valor numérico válido.");
                txtA.Focus();
            }
            else if (double.Parse(txtA.Text) <= 0)
            {
                errorProvider1.SetError(txtA, "Por favor, insira um valor numérico maior que 0.");
                txtA.Focus();
            }
            else
            {
                A = double.Parse(txtA.Text);
                errorProvider1.Clear();
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtB.Text, out double result))
            {
                errorProvider1.SetError(txtB, "Por favor, insira um valor numérico válido.");
                txtB.Focus();
            }
            else if (double.Parse(txtB.Text) <= 0)
            {
                errorProvider1.SetError(txtB, "Por favor, insira um valor numérico maior que 0.");
                txtB.Focus();
            }
            else
            {
                B = double.Parse(txtB.Text);
                errorProvider1.Clear();
            }

        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtC.Text, out double result))
            {
                errorProvider1.SetError(txtC, "Por favor, insira um valor numérico válido.");
                txtC.Focus();
            }
            else if (double.Parse(txtC.Text) <= 0)
            {
                errorProvider1.SetError(txtC, "Por favor, insira um valor numérico maior que 0.");
                txtC.Focus();
            }
            else
            {
                C = double.Parse(txtC.Text);
                errorProvider1.Clear();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtTipTriangle.Clear();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Calculadora_Tipo_Triângulo()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((B - C > A) || (B + C < A) && (A - C > B) || (A + C < B) && (A - C > B) || (A + C < B))
            {
                MessageBox.Show("Os valores dos lados não formam um triângulo, tente novamente");
                txtA.Focus();
            }
            else if ((A == B) && (B == C))
            {
                txtTipTriangle.Text = "Triângulo Equilátero.";
            }
            else if ((A != B) && (B != C))
            {
                txtTipTriangle.Text = "Triângulo Escaleno.";
            }
            else
            {
                txtTipTriangle.Text = "Triângulo Isósceles.";
            }
        }
    }
}
